# Personal Portfolio Website

## Tech Stack

1. React JS
2. Tailwind CSS
3. Vercel - Deployment
