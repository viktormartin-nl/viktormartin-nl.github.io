function Button({ title }) {
	return <button>{title}</button>;
}

export default Button;